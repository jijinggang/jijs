# myjs
常用的js脚本通用命令集
